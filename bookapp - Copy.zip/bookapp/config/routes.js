/**
 * Route Mappings
 * (sails.config.routes)
 *
 * Your routes tell Sails what to do each time it receives a request.
 *
 * For more information on configuring custom routes, check out:
 * https://sailsjs.com/anatomy/config/routes-js
 */

module.exports.routes = {
      '/': { view: 'pages/homepage' },
      //Books Controller
      'GET /books/list/': 
      {
       controller: 'BooksController',
       action: 'list'
      },
      'GET /books/add': 
      {
       controller: 'BooksController',
       action: 'add'
      },
      'POST /books/create':
      {
       controller: 'BooksController',
       action: 'create'
      },
      'GET /books/edit/:id': 'BooksController.edit',
      'POST /update/:id': 
      { 
       controller: 'BooksController',
       action: 'update',
       skipAssets: true
      },
      'POST /delete/:id': 
      { 
       controller: 'BooksController',
       action: 'delete',
       skipAssets: true
      },

      //Authors Controller
      'GET /authors/list': 
      {
       controller: 'AuthorsController',
       action: 'list'
      },
      'GET /authors/add': 
      {
       controller: 'AuthorsController',
       action: 'add'
      },
      'POST /authors/create':
      {
       controller: 'AuthorsController',
       action: 'create'
      },
      'POST /authors/delete/:id': 
      { 
       controller: 'AuthorsController',
       action: 'delete',
       skipAssets: true
      },
      'GET /authors/edit/:id': 'AuthorsController.edit',
      'POST /authors/update/:id': 
      { 
       controller: 'AuthorsController',
       action: 'update',
       skipAssets: true
      },
};
