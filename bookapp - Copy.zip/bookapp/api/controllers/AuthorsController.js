/**
 * AuthorsController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {

    list:async function(req,res)
    {
       await Authors.find({}).exec(function(err, authors){
                if(err){
                    res.send(500, {error: 'Database Error'});
                }
                res.view('pages/authors/list', {authors:authors});
            });
    },
    add: async function(req, res){
        await Authors.find({}).exec(function(err, authors){
            if(err){
                res.send(500, {error: 'Database Error'});
            }
            res.view('pages/authors/add', {authors:authors});
        });
    },
    
    create: async function(req, res){
        var name = req.body.name;
        var address = req.body.address
        var phone = req.body.phone
        var insertAuthors = await Authors.create({name:name,address:address,phone:phone}).fetch();
            if(insertAuthors)  res.redirect('/authors/list');
            else res.send(500, {error: res.toString()});
    },

    delete: async function(req, res){
        var deleteAuthors = await Authors.destroyOne({id :req.params.id});  
        if(deleteAuthors) res.redirect('/authors/list');
        else res.send(500, {error: res.toString()});
        return false;
    },

    edit: async function(req, res){
        await Authors.findOne({id:req.params.id}).exec(function(err, author){
            if(err){
                res.send(500, {error:err.toString()});
            }
            res.view('pages/authors/edit', {author:author});
        });
    },
    update: async function(req, res){
        var name = req.body.name;
        var id = await Authors.findOne({id:req.params.id});  
        var updatedRecord = await Authors.updateOne(id).set({name:name});
        if(updatedRecord) res.redirect('/authors/list');
        else res.send(500, {error: res.toString()});
        return false;
    }

};

