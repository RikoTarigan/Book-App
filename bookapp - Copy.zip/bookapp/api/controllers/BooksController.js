/**
 * BooksController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {
  
    list:async function(req,res)
    {
       await Books.find({}).exec(function(err, books){
                if(err){
                    res.send(500, {error: 'Database Error'});
                }
                res.view('pages/list', {books:books});
            });
    },
    add: async function(req, res){
        await Books.find({}).exec(function(err, books){
            if(err){
                res.send(500, {error: 'Database Error'});
            }
             Authors.find({}).exec(function(err, authors){
                if(err){
                    res.send(500, {error: 'Database Error'});
                }                
            res.view('pages/add', {authors:authors});
            })
        });
    },
    create: async function(req, res){
        var title = req.body.title;
        var body = req.body.body;
        var author = req.body.author;
        var page = req.body.page;
        var stock = req.body.stock;
        var insertBooks = await Books.create({title:title, body:body,author:author,page:page,stock:stock}).fetch();
            if(insertBooks)  res.redirect('/books/list');
            else res.send(500, {error: res.toString()});
    },
    delete: async function(req, res){
        var deleteBooks = await Books.destroyOne({id :req.params.id});  
        if(deleteBooks) res.redirect('/books/list');
        else res.send(500, {error: res.toString()});
        return false;
    },
    edit: async function(req, res){
      await Authors.find({}).exec(function(err, authors){
        var result = authors
            if(err){
                res.send(500, {error: 'Database Error'});
            }                
        Books.findOne({id:req.params.id}).exec(function(err, book,authors){
            authors=result
            if(err){
                res.send(500, {error:err.toString()});
            }
            res.view('pages/edit/', {book:book,authors:authors});
        });
        })
    },
    update: async function(req, res){
        var title = req.body.title;
        var body = req.body.body;
        var author = req.body.author;
        var page = req.body.page;
        var stock = req.body.stock;
        var id = await Books.findOne({id:req.params.id});  
        var updatedRecord = await Books.updateOne(id).set({title:title, body:body,author:author,page:page,stock:stock});
        if(updatedRecord) res.redirect('/books/list');
        else res.send(500, {error: err.toString()});
        return false;
    },
};
